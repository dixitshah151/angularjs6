import { Component } from '@angular/core';

import { Http } from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  title = 'HI Component';
  path = "https://www.scientiamobile.com/images/logo_500.png"

    size_c=90

  colval = 2

  btntype1 =true;
  btntype2 = false;

  colorName1 = "green"
  colorName2 = "blue"

  showData(){
    
  	console.log("button Clicked")
  }
  
  showDivData(){
  	
  	console.log("Div Clicked")

  }


  callMethod(){
  	console.log( "HELO")
  }


  showEmail(data){
  	console.log( data );
  }

  useremail = "hello@gmail.com"
  usermobile = 9009009009

  

  listUsers = {
  	name:'Ajay shah',
  	rating:3.5678,
  	price:23.97,
  	students:340023,
  	releaseDate: new Date(2016 ,  3, 22)
  }
  
  /****************** ng if ****************/
  forIf1 = true;
  forIf2 = false;
 

  isCount = [100,200];
  // isCount = [];

  // isCount1 = [100,200,300];
  isCount1 = [];
  /****************** ng if ****************/


  ngForvar1 = [100,200,300];
  /*
    0=>100
    1=>200
  */


  ngForvar2 = [
      {name:'Ajay',age:20},
      {name:'Amit',age:22},
      {name:'Samit',age:15}
  ];
  

  isHidden1=true
  isHidden2=false


  viewMode = "register"


   posts:any[];
   constructor(private http:Http){
     // console.log(this.http)
     this.http.get("http://localhost:4444/users").subscribe(
       (response)=>{
         //Its a RAW Format
         // console.log(response);
         //Its a JSON Format
         // console.log(response.json());
         this.posts = response.json();
       },
       (error)=>{
         console.log(error);
       }
     );

       
   }

   addUser(username){
       // console.log(username)
       this.http.post("http://localhost:4444/users",{name:username}).subscribe(
           (response)=>{
             console.log(response.json());
           }
         );
     }

     updateUsers(posts){
       // this.http.put => to update all data
       // this.http.patch => to update some content
       const headers = new Headers();
        headers.append('Content-Type', 'application/json');
        const options = new RequestOptions({headers: headers});
       var data = JSON.stringify( {name:"NEW USER UPDATED"} );
         this.http.put("http://localhost:4444/users/"+posts.id,data,options).subscribe(
           (response)=>{
             console.log(response.json());
           }
         );
     }
     deleteUsers(posts){
      
         this.http.delete("http://localhost:4444/users/"+posts.id).subscribe(
           (response)=>{
             console.log(response.json());
           }
         );
     }

     status=false

     css_red = false

     sendsms(val){
       if(val.length == 10){

         this.status=false
         this.css_red=false
         // console.log(this.httpdata)
         var url = "http://api.textlocal.in/send/?username=vijay7498@gmail.com&hash=64edbd875d9d3b3158de596f013c46793d698a1a39a0231c5e3d9f272630b26c&message=TEST MESSAGE&sender=TXTLCL&numbers=91"+val+"&test=0"

         //9619404202
         this.httpdata.get(url).subscribe(
             (response)=>{
                 console.log(response)
             }
          );
       }
       else{

         this.status=true
         this.css_red=true

       }
     }

     // constructor(private httpdata:Http){
     //   // console.log(this.httpdata)
     // }
}
