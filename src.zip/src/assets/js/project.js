$(function() {
    // alert(10000);
    var pat = "http://localhost/ecommmercecodeigniter/index.php/";
    $("#log_btn").click(function() {
        // alert(1000);
        $.ajax({
            type: "post",
            data: $("#log_form").serialize(),
            url: pat + "home/log_action",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                if (ans_from_data == 1) {
                    window.location.href = pat + "home/index";
                } else {
                    $("#log_err").text(ans_from_data);
                }
            }
        })
    })
    $("#changepass_btn").click(function() {
        // alert(1000);
        $.ajax({
            type: "post",
            data: $("#changepass_form").serialize(),
            url: pat + "home/changepass_action",
            success: function(ans_from_data) {
                $("#changepass_err").text(ans_from_data);
                // alert(ans_from_data);
                if (ans_from_data == 1) {

                    window.location.href = pat + "home/change_pass";
                    $("#changepass_err").text("Your Password success Fully");
                } else {
                    $("#changepass_err").text(ans_from_data);
                }
            }
        })
    })
    $("#form2,#form3").hide();
    $(".forgot1").click(function() {
        // alert(10000);
        $.ajax({
            type: "post",
            data: $("#fpass1").serialize(),
            url: pat + "home/forgotpass_action1",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                if (ans_from_data == 1) {
                    $("#form1,#form2").slideToggle();
                } else {
                    $("#err1").html(ans_from_data);
                }

            }
        })
    })
    $(".forgot2").click(function() {
        // alert(10000);
        $.ajax({
            type: "post",
            data: $("#fpass2").serialize(),
            url: pat + "home/forgotpass_action2",
            success: function(ans_from_data) {
                // $("#err2").html(ans_from_data);
                if (ans_from_data == 1) {
                    $("#form2,#form3").slideToggle();
                } else {
                    $("#err2").html(ans_from_data);
                }

            }
        })
    })
    $(".forgot3").click(function() {
        // alert(10000);
        $.ajax({
            type: "post",
            data: $("#fpass3").serialize(),
            url: pat + "home/forgotpass_action3",
            success: function(ans_from_data) {
                if (ans_from_data == 1) {
                    $("#err3").html("you will redirect loginpage in 5 second");
                    setTimeout(function() {
                        window.location.href = pat + "home/login";
                    }, 5000);
                } else {
                    $("#err3").html(ans_from_data);
                }


            }
        })
    })
    $(".productcategory").click(function() {
        // alert(1000);
        $.ajax({
            type: "post",
            data: $("#productadd").serialize(),
            url: pat + "home/category_action",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                $("#err1").html(ans_from_data);
            }
        })
    })
    $(".productbrand").click(function() {
        // alert(1000);
        $.ajax({
            type: "post",
            data: $("#brandadd").serialize(),
            url: pat + "home/brand_action",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                $("#err1").html(ans_from_data);
            }
        })
    })


    $(".subcategory").click(function() {
        // alert(1000);
        $.ajax({
            type: "post",
            data: $("#sub_catadd").serialize(),
            url: pat + "home/sub_cataction",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                $("#err1").html(ans_from_data);
            }
        })
    })

    $(".btnadmin_regis").click(function() {
        // alert(1000);
        $.ajax({
            type: "post",
            data: $("#regisadmin_form").serialize(),
            url: pat + "home/admin_regisaction",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                // $("#err1").html(ans_from_data);
                if (ans_from_data == 1) {
                    // $("#err1").html("you will redirect loginpage in 5 second");
                   
                        window.location.href = pat + "home/viewuser";
                   
                } else {
                    $("#err1").html(ans_from_data);
                }

            }
        })
    })
    $("#btn_adminlogin").click(function() {
        // alert(1000);
        $.ajax({
            type: "post",
            data: $("#loginadmin_form").serialize(),
            url: pat + "home/admin_loginaction",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                if (ans_from_data == 1) {

                    window.location.href = pat + "home/admin_show";
                } else {
                    $("#err1").html(ans_from_data);
                }
            }
        })
    })


    $(".admin_delete").click(function(){
    	// alert(1000);
    	var id = $(this).attr("for");
        //alert(id);
        $.ajax({
            type: "post",
            data: "rec=" + id,
            url: pat + "home/admin_delete",
            success: function(xyz) {
                // alert(xyz);
                if(xyz == 1){
                	alert("User Deleted successfully");
                    setTimeout(function() {
                       window.location.href=pat + "home/viewuser";
                    }, 2000);
                	
                }
                else{
                	alert(xyz);
                }
                // $(".new_data").html(xyz)


            }

        })
    })
    $(".brand_del").click(function(){
      //  alert(1000);
         var id = $(this).attr("for");
        //alert(id);
        $.ajax({
            type: "post",
            data: "rec=" + id,
            url: pat + "home/brand_del",
            success: function(xyz) {
                 // alert(xyz);
                if(xyz == 1){
                    alert("Brand Deleted successfully");
                    setTimeout(function() {
                       window.location.href=pat + "home/admin_brand";
                    }, 2000);
                    
                }
                else{
                    alert(xyz);
                }
                //$(".new_data").html(xyz)


             }

        })
     })
        $(".category_delete").click(function(){
            // alert(1000);
            var id = $(this).attr("for");
            // alert(id);
            $.ajax({
            type: "post",
            data: "rec=" + id,
            url: pat + "home/category_del",
            success: function(xyz) {
                  // alert(xyz);
                if(xyz == 1){
                    alert("Category Deleted successfully");
                    setTimeout(function() {
                       window.location.href=pat + "home/admin_category";
                    }, 2000);
                    
                }
                else{
                    alert(xyz);
                }
                //$(".new_data").html(xyz)


             }

        })
     })
    $(".subcat_del").click(function(){
       //      alert(1000);
            var id = $(this).attr("for");
            // alert(id);
            $.ajax({
            type: "post",
            data: "rec=" + id,
            url: pat + "home/subcat_del",
            success: function(xyz) {
                  // alert(xyz);
                if(xyz == 1){
                    alert("Sub-Category Deleted successfully");
                    setTimeout(function() {
                       window.location.href=pat + "home/admin_Subcategory";
                    }, 1000);
                    
                }
                else{
                    alert(xyz);
                }
                //$(".new_data").html(xyz)


             }

        })
     })
   $(".btnadmin_update").click(function(){
             // alert(1000);
         $.ajax({
            type: "post",
            data: $("#adminupdate_form").serialize(),
            url: pat + "home/admin_loginupdateaction",
            success: function(ans_from_data) {
                alert(ans_from_data);
                if (ans_from_data == 1) {
                    alert("Record successfully updated");
                    window.location.href = pat + "home/viewuser";
                } else {
                   alert("record Unsuccessfully updated");
                }
            }
        }) 
     })

   $(".brandedit").click(function(){
             // alert(1000);
         $.ajax({
            type: "post",
            data: $("#brandedit").serialize(),
            url: pat + "home/brandedit",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                if (ans_from_data == 1) {
                    alert("Record successfully updated");
                    window.location.href = pat + "home/admin_brand";
                } else {
                   alert("record Unsuccessfully updated");
                }
            }
        }) 
     })
   $(".categoryedit").click(function(){
             // alert(1000);
         $.ajax({
            type: "post",
            data: $("#productedit").serialize(),
            url: pat + "home/categoryadminedit",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                if (ans_from_data == 1) {
                    alert("Record successfully updated");
                    window.location.href = pat + "home/admin_category";
                } else {
                   alert("record Unsuccessfully updated");
                }
            }
        }) 
     })

   $(".subcategoryedit").click(function(){
             // alert(1000);
         $.ajax({
            type: "post",
            data: $("#sub_cataddedit").serialize(),
            url: pat + "home/subcategoryadminedit",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                if (ans_from_data == 1) {
                    alert("Record successfully updated");
                    window.location.href = pat + "home/admin_Subcategory";
                } else {
                   alert("record Unsuccessfully updated");
                }
            }
        }) 
     })
   $(".btn_addproduct").click(function(){
    // alert(1000);
    $.ajax({
            type: "post",
            data: $("#product_admin").serialize(),
            url: pat + "home/addproduct_admin",
            success: function(ans_from_data) {
                // alert(ans_from_data);
                
                if (ans_from_data == 1) {
                    alert("Record added successfully");
                    window.location.href = pat + "home/admin_product";
                    // $("#err1").html(ans_from_data);
                } else {
                   alert("record Unsuccessfully added");
                }
            }
        }) 
   })
   $(".btn_banneradd").click(function(){
    // alert(10000);
            $.ajax({
                 type: "post",
                    data: $("#banner_addadmin").serialize(),
                    url: pat + "home/addbanner_admin",
                    success: function(ans_from_data) {
                        // alert(ans_from_data);
                         $("#err1").html(ans_from_data);
                        if (ans_from_data == 1) {
                            alert("Record added successfully");
                            window.location.href = pat + "home/view_banner";
                            // $("#err1").html(ans_from_data);
                        } else {
                           alert("record Unsuccessfully added");
                        }
                    }

            })
   })
   $(".btn_banneredit").click(function(){
    // alert(10000);
            $.ajax({
                 type: "post",
                    data: $("#banner_editadmin").serialize(),
                    url: pat + "home/editbanner_admin",
                    success: function(ans_from_data) {
                        // alert(ans_from_data);
                         // $("#err1").html(ans_from_data);
                        if (ans_from_data == 1) {
                            alert("Record added successfully");
                            window.location.href = pat + "home/view_banner";
                            // $("#err1").html(ans_from_data);
                        } else {
                           alert("record Unsuccessfully added");
                        }
                    }

            })
   })
   $(".btn_global").click(function(){
    // alert(1000);
         $.ajax({
                 type: "post",
                    data: $("#websetting").serialize(),
                    url: pat + "home/editglobal",
                    success: function(ans_from_data) {
                        // alert(ans_from_data);
                         // $("#err1").html(ans_from_data);
                        if (ans_from_data == 1) {
                            alert("Record Updated successfully");
                            window.location.href = pat + "home/globalsetting";
                            // $("#err1").html(ans_from_data);
                        } else {
                           alert("record Unsuccessfully Updated");
                        }
                    }

            })
   })

})